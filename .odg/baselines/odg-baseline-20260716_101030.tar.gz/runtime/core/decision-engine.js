#!/usr/bin/env node

const fs=require("fs");
const {loadRuntimeContext}=require("./runtime-context-loader");

const mission=process.argv[2]||"BUILD_RUNTIME";

const knowledge=JSON.parse(
fs.readFileSync("runtime/generated/knowledge.json","utf8")
);

const p=knowledge.project;

const missionStrategies={
  PROJECT_CONTEXT_ENGINE_V1:[
    "LOAD_PROJECT_CONTEXT",
    "ANALYZE_PROJECT",
    "REGISTER_CAPABILITY",
    "VALIDATE_CONTEXT",
    "REPORT_CONTEXT"
  ]
};

const runtimeContext=loadRuntimeContext(mission);

const actions=[];

if(p.todos>0)
    actions.push("PROCESS_TODOS");

if(p.fixmes>0)
    actions.push("PROCESS_FIXMES");

if(p.relativeImports>100)
    actions.push("ANALYZE_DEPENDENCIES");

if(p.packageImports>500)
    actions.push("OPTIMIZE_DEPENDENCIES");

if(knowledge.missingCapabilities.length>0)
    actions.push("IMPLEMENT_MISSING_CAPABILITIES");

const result={
    generatedAt:new Date().toISOString(),
    mission:knowledge.mission,
    status:"READY",
    priority:actions.length>3?"HIGH":"NORMAL",
    actions:(missionStrategies[mission]||actions),
    metrics:p
};

fs.writeFileSync(
"runtime/generated/decision.json",
JSON.stringify(result,null,2)
);

console.log("======================================");
console.log("DECISION ENGINE v3");
console.log("======================================");
console.log("Context Files :",runtimeContext.project.files);
console.log("Context Dirs  :",runtimeContext.project.directories);
console.log("Priority :",result.priority);
console.log("Actions  :",result.actions.length);

for(const a of result.actions)
    console.log(" -",a);

console.log("======================================");
