# NEXT SESSION

Sprint : 15

Mission officielle :
Runtime Integration.

Principe :
Extension avant réécriture.

Le Runtime doit produire son plan avant toute modification.
