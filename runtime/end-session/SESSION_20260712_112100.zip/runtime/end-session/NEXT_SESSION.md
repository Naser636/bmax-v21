# NEXT SESSION

Mission :
Sprint 14

Premier objectif :
Consolider le Runtime avec l'architecture existante.

Règle :
Extension uniquement.
Aucune réécriture des fondations.
